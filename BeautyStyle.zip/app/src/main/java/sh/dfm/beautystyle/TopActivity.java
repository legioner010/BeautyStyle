package sh.dfm.beautystyle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import android.widget.TextView;

public class TopActivity extends AppCompatActivity  implements View.OnClickListener{

    private ImageView nailIv;
    private TextView nailTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top);

        nailIv = (ImageView) findViewById(R.id.im_nail);
        nailTv = (TextView) findViewById(R.id.tv_nail);

        nailTv.setOnClickListener(this);
        nailIv.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if(view.equals(nailTv) || view.equals(nailIv)){
            Intent intent = new Intent(this, NailCategoryActivity.class);
            startActivity(intent);
        }
    }
}
